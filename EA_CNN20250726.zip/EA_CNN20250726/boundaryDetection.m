function boundedIndividual = boundaryDetection(lowerBounds, upperBounds, individual)
     assert(numel(lowerBounds) == numel(upperBounds), '');
    assert(numel(lowerBounds) == numel(individual), '');
    
       boundedIndividual = zeros(size(individual));
    
        for i = 1:numel(lowerBounds)
      
        if individual(i) < lowerBounds(i)
            boundedIndividual(i) = lowerBounds(i); 
        elseif individual(i) > upperBounds(i)
            boundedIndividual(i) = upperBounds(i); 
        else
            boundedIndividual(i) = individual(i); 
        end
        
        if i==4
            boundedIndividual(i)=floor(boundedIndividual(i));
        end

    end
end