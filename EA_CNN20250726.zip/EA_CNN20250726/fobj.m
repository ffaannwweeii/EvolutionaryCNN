function Fitness=fobj(solution,data)
       % data = data(2:end, :);
    
    x1=solution(1);
    x2=solution(2);
    x3=solution(3);
    x4=solution(4);
    
       features = data(:, 1:end-1);
    num_dim=size(features,2);
    labels = data(:, end);
    
       uniqueLabels = unique(labels);
    num_class=size(uniqueLabels,1);
    trainFeatures = [];
    trainLabels = [];
    testFeatures = [];
    testLabels = [];
    
       num_size=0.7;
    for i = 1 : numel(uniqueLabels)
        mid_data = data((data(:, end) == i), :);          
        mid_size = size(mid_data, 1);                    
        mid_tiran = round(num_size * mid_size);            
        trainFeatures = [trainFeatures; mid_data(1: mid_tiran, 1: end - 1)];      
        trainLabels = [trainLabels; mid_data(1: mid_tiran, end)];                 
        testFeatures  = [testFeatures; mid_data(mid_tiran + 1: end, 1: end - 1)]; 
        testLabels  = [testLabels; mid_data(mid_tiran + 1: end, end)];        
    end
    



    trainFeatures = trainFeatures';
    trainLabels = trainLabels';
    testFeatures = testFeatures';
    testLabels = testLabels';
    M = size(trainFeatures, 2);
    N = size(testFeatures , 2);

    %%  数据归一化
    [trainFeatures, ps_input] = mapminmax(trainFeatures, 0, 1);
    testFeatures  = mapminmax('apply', testFeatures, ps_input);
    
    trainLabels =  categorical(trainLabels)';
    testLabels  =  categorical(testLabels )';

    trainFeatures =  double(reshape(trainFeatures, num_dim, 1, 1, M));
    testFeatures  =  double(reshape(testFeatures , num_dim, 1, 1, N));
    % 构造网络结构
    layers = [
    imageInputLayer([num_dim, 1, 1])                         
    convolution2dLayer([2, 1], 16, 'Padding', 'same')       
    batchNormalizationLayer                             
    reluLayer                                             
    
    maxPooling2dLayer([2, 1], 'Stride', [2, 1])             

    convolution2dLayer([2, 1], 32, 'Padding', 'same')      
    batchNormalizationLayer                             
    reluLayer                                               

    fullyConnectedLayer(num_class)                         
    softmaxLayer                                            
    classificationLayer];                                   

   
    options = trainingOptions('adam', ...                     
        'MaxEpochs', 500, ...                                   
        'InitialLearnRate', x1, ...                          
        'L2Regularization', x2, ...                          
        'LearnRateSchedule', 'piecewise', ...                  

        'LearnRateDropFactor', x3, ...                         
        'LearnRateDropPeriod', x4, ...                      
        'Shuffle', 'every-epoch', ...                          
        'ValidationPatience', Inf, ...                          
        'Plots', 'none', ...                       
        'Verbose', false);

  
    net = trainNetwork(trainFeatures, trainLabels, layers, options);
    predictedLabels = classify(net, testFeatures);

  
    accuracy = sum(predictedLabels == testLabels) / numel(testLabels);
    Fitness=accuracy;
end