clear all 
close all
clc
tic 
addpath(genpath(pwd));
SearchAgents_no=5; % Number of search agents
dim=4;
Maxiteration=5; 
algorithmName={'WOA','SMA'};
Flod=2;
algrithmNum=size(algorithmName,2);
Function_name_all={'F1'}; %不同的函数代表不同的数据集,初始版本都是文本数据

for funcNum=1:size(Function_name_all,2)
    Function_name=Function_name_all{funcNum};
    [data,lb,ub]=Get_Functions(Function_name);

    for cflod=1:Flod
        display(['flod',num2str(cflod)]);
        for cnum=1:algrithmNum
            alg_fhd=str2func(algorithmName{cnum});

            [~,cg_curve]=alg_fhd(SearchAgents_no,Maxiteration,lb,ub,dim,data);
        end
    end 

end