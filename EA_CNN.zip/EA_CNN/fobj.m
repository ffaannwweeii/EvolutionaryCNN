function Fitness=fobj(solution,data)
    % 去除第一行行标签
    % data = data(2:end, :);
    
    x1=solution(1);
    x2=solution(2);
    x3=solution(3);
    x4=solution(4);
    
    % 获取特征和标签
    features = data(:, 1:end-1);
    num_dim=size(features,2);
    labels = data(:, end);
    
    % 获取唯一的标签类别
    uniqueLabels = unique(labels);
    num_class=size(uniqueLabels,1);
    trainFeatures = [];
    trainLabels = [];
    testFeatures = [];
    testLabels = [];
    
    % 对每个标签类别进行处理
    num_size=0.7;
    for i = 1 : numel(uniqueLabels)
        mid_data = data((data(:, end) == i), :);           % 循环取出不同类别的样本
        mid_size = size(mid_data, 1);                    % 得到不同类别样本个数
        mid_tiran = round(num_size * mid_size);         % 得到该类别的训练样本个数
    
        trainFeatures = [trainFeatures; mid_data(1: mid_tiran, 1: end - 1)];       % 训练集输入
        trainLabels = [trainLabels; mid_data(1: mid_tiran, end)];              % 训练集输出
    
        testFeatures  = [testFeatures; mid_data(mid_tiran + 1: end, 1: end - 1)];  % 测试集输入
        testLabels  = [testLabels; mid_data(mid_tiran + 1: end, end)];         % 测试集输出
    end
    



    trainFeatures = trainFeatures';
    trainLabels = trainLabels';
    testFeatures = testFeatures';
    testLabels = testLabels';
    M = size(trainFeatures, 2);
    N = size(testFeatures , 2);

    %%  数据归一化
    [trainFeatures, ps_input] = mapminmax(trainFeatures, 0, 1);
    testFeatures  = mapminmax('apply', testFeatures, ps_input);
    
    trainLabels =  categorical(trainLabels)';
    testLabels  =  categorical(testLabels )';

    trainFeatures =  double(reshape(trainFeatures, num_dim, 1, 1, M));
    testFeatures  =  double(reshape(testFeatures , num_dim, 1, 1, N));
    % 构造网络结构
    layers = [
    imageInputLayer([num_dim, 1, 1])                        % 输入层
    
    convolution2dLayer([2, 1], 16, 'Padding', 'same')       % 卷积核大小为 2*1 生成16个卷积
    batchNormalizationLayer                                 % 批归一化层
    reluLayer                                               % relu 激活层
    
    maxPooling2dLayer([2, 1], 'Stride', [2, 1])             % 最大池化层 大小为 2*1 步长为 [2, 1]

    convolution2dLayer([2, 1], 32, 'Padding', 'same')       % 卷积核大小为 2*1 生成32个卷积
    batchNormalizationLayer                                 % 批归一化层
    reluLayer                                               % relu 激活层

    fullyConnectedLayer(num_class)                          % 全连接层（类别数） 
    softmaxLayer                                            % 损失函数层
    classificationLayer];                                   % 分类层

    % 参数设置
    options = trainingOptions('adam', ...                       % Adam 梯度下降算法
        'MaxEpochs', 500, ...                                   % 最大训练次数 500
        'InitialLearnRate', x1, ...                           % 初始学习率为 0.001 x1
        'L2Regularization', x2, ...                           % L2正则化参数 x2
        'LearnRateSchedule', 'piecewise', ...                   % 学习率下降   0.1 x3
        'LearnRateDropFactor', x3, ...                         % 学习率下降因子 
        'LearnRateDropPeriod', x4, ...                         % 经过450次训练后 学习率为 0.001 * 0.1 x4
        'Shuffle', 'every-epoch', ...                           % 每次训练打乱数据集
        'ValidationPatience', Inf, ...                          % 关闭验证
        'Plots', 'none', ...                       % 画出曲线
        'Verbose', false);

    % 训练模型
    net = trainNetwork(trainFeatures, trainLabels, layers, options);
    predictedLabels = classify(net, testFeatures);

    % 计算准确率
    accuracy = sum(predictedLabels == testLabels) / numel(testLabels);
    Fitness=accuracy;
end