function boundedIndividual = boundaryDetection(lowerBounds, upperBounds, individual)
    % 输入参数：
    %   lowerBounds: 一个数组，包含每个维度的下界
    %   upperBounds: 一个数组，包含每个维度的上界
    %   individual: 一个包含个体的数组，每个元素表示个体在对应维度的值
    % 输出参数：
    %   boundedIndividual: 经过边界检测后的个体数组
    
    % 确保输入参数合法
    assert(numel(lowerBounds) == numel(upperBounds), '上下界数组长度不一致');
    assert(numel(lowerBounds) == numel(individual), '上下界数组长度与个体数组长度不一致');
    
    % 初始化边界检测后的个体数组
    boundedIndividual = zeros(size(individual));
    
    % 遍历每个维度
    for i = 1:numel(lowerBounds)
        % 边界检测
        if individual(i) < lowerBounds(i)
            boundedIndividual(i) = lowerBounds(i); % 超出下界，将值设为下界
        elseif individual(i) > upperBounds(i)
            boundedIndividual(i) = upperBounds(i); % 超出上界，将值设为上界
        else
            boundedIndividual(i) = individual(i); % 在界内，保持原值
        end
        
        if i==4
            boundedIndividual(i)=floor(boundedIndividual(i));
        end

    end
end