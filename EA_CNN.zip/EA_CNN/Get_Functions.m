function [output_matrix,lb,ub] = Get_Functions(F)
    ub=[0.01 0.001 0.2 500];
    lb=[1e-7 1e-7 1e-7 300];%暂定边界,优化的超参数有6个
    % 根据输入的测试函数名称 F 选择相应的 Excel 文件
    switch F
        case 'F1'
            excel_file = 'excel1.xlsx';
        case 'F2'
            excel_file = 'excel2.xlsx';
        % 添加更多的测试函数名称和相应的 Excel 文件
        % case 'F3'
        %     excel_file = 'excel3.xlsx';
        % case 'F4'
        %     excel_file = 'excel4.xlsx';
        otherwise
            error('未找到与输入的测试函数名称匹配的 Excel 文件');
    end
    

    
    % 导入 Excel 文件的数据
    data = xlsread(excel_file);
    
    % 返回导入的数据
    output_matrix = data;
end