function [output_matrix,lb,ub] = Get_Functions(F)
    ub=[0.01 0.001 0.2 500];
    lb=[1e-7 1e-7 1e-7 300];
        switch F
        case 'F1'
            excel_file = 'excel1.xlsx';
        case 'F2'
            excel_file = 'excel2.xlsx';
               otherwise
            error('No found Excel 文件');
    end
    

    
    
    data = xlsread(excel_file);
    
        output_matrix = data;
end